import { IResult } from "./result.js";

type ITrainer = {
  username: string;
  decks: IDeck[];
};

type IDeck = {
  name: string;
  pokemons: string[];
};

const trainerStore = new Map<string, ITrainer>();

const ErrorDeckAlreadyExist = { kind: "deck-already-exist" } as const;
const ErrorDeckNotFound = { kind: "deck-not-found" } as const;

export function getTrainer({ username }: { username: string }): ITrainer {
  let stored = trainerStore.get(username);
  if (!stored) {
    stored = {
      username,
      decks: [],
    };
    trainerStore.set(username, stored);
  }
  return stored;
}

export function getDeckList({ username }: { username: string }): string[] {
  const trainer = getTrainer({ username });
  return trainer.decks.map((deck) => deck.name);
}

export function createDeck({
  username,
  name,
}: {
  username: string;
  name: string;
}): IResult<IDeck, typeof ErrorDeckAlreadyExist> {
  const trainer = getTrainer({ username });
  const deckIndex = trainer.decks.findIndex((t) => t.name === name);
  if (deckIndex !== -1) {
    return [ErrorDeckAlreadyExist];
  }
  const deck = {
    name,
    pokemons: [],
  };
  trainer.decks.push(deck);
  return [null, deck];
}

export function getDeck({
  username,
  name,
}: {
  username: string;
  name: string;
}): IResult<IDeck, typeof ErrorDeckNotFound> {
  const trainer = getTrainer({ username });
  const deck = trainer.decks.find((t) => t.name === name);
  if (deck) {
    return [null, deck];
  } else {
    return [ErrorDeckNotFound];
  }
}

export function updateDeck({
  username,
  name,
  pokemons,
}: {
  username: string;
  name: string;
  pokemons: string[];
}): IResult<IDeck, typeof ErrorDeckNotFound> {
  const trainer = getTrainer({ username });
  const deck = trainer.decks.find((t) => t.name === name);
  if (deck) {
    deck.pokemons = pokemons;
    return [null, deck];
  } else {
    return [ErrorDeckNotFound];
  }
}

export function deleteDeck({
  username,
  name,
}: {
  username: string;
  name: string;
}): IResult<true, typeof ErrorDeckNotFound> {
  const trainer = getTrainer({ username });
  const trainerIndex = trainer.decks.findIndex((t) => t.name === name);
  if (trainerIndex === -1) {
    return [ErrorDeckNotFound];
  } else {
    trainer.decks.splice(trainerIndex, 1);
    return [null, true];
  }
}
