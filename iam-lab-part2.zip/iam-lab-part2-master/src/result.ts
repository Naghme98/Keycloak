export type IResult<T, E> = [err: E] | [err: null, data: T];
