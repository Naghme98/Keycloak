import axios from "axios";
import kcConfig from "../keycloak.json";

const kcUrl = kcConfig["auth-server-url"];
const realm = kcConfig["realm"];
const clientId = kcConfig["resource"];
const clientSecret = kcConfig["credentials"]["secret"];

// ["deck", "user1", "deck1"] -> "deck|user1|deck1"
export const encodeResourceName = (...parts: string[]) => {
  return parts.map((part) => encodeURIComponent(part)).join("|");
};

export const createDeckListResource = async (username: string) => {
  return createResource({
    name: encodeResourceName("deck_list", username),
    owner: username,
    ownerManagedAccess: false,
    scopes: ["deck_list:read"],
  });
};

export const createDeckResource = async (
  username: string,
  deckName: string
) => {
  return createResource({
    name: encodeResourceName("deck", username, deckName),
    owner: username,
    ownerManagedAccess: true,
    scopes: ["deck:read", "deck:write", "deck:delete"],
  });
};

const createResource = async (
  resource: Record<string, unknown> & { name: string }
) => {
  const pat = await getPat();
  return axios
    .post(`${kcUrl}/realms/${realm}/authz/protection/resource_set`, resource, {
      headers: {
        authorization: `Bearer ${pat}`,
      },
    })
    .catch((err) => {
      console.log(`Resource already exist - ${resource.name}`);
    });
};

const getPat = () => {
  return axios
    .post(
      `${kcUrl}/realms/${realm}/protocol/openid-connect/token`,
      `grant_type=client_credentials&client_id=${clientId}&client_secret=${clientSecret}`,
      {
        headers: { "content-type": "application/x-www-form-urlencoded" },
      }
    )
    .then((res) => res.data.access_token)
    .catch(() => {
      console.error("Could not get PAT");
    });
};
