## Launch

- Install node lts - <https://nodejs.org/en/>
- Install dependencies and run

```sh
      npm install --global yarn
      yarn install
      yarn start
```

- Service should be available at `http://localhost:3069`
