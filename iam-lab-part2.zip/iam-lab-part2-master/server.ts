import Keycloak from "keycloak-connect";
import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import * as resources from "./src/resources";
import * as trainerStore from "./src/trainer-store";

const keycloak = new Keycloak({});
const app = express();
app.use(bodyParser.json());
app.use(
  cors({
    origin: (requestOrigin, callback) => {
      callback(
        null,
        requestOrigin === "http://localhost:3068" ? [requestOrigin] : undefined
      );
    },
  })
);

app.post("/deck-create/:name", async (req, res) => {
  const grantAuthN = await checkAuth(req);
  if (!grantAuthN) {
    res.status(401).json({ error: "access_denied" });
  } else {
    const decision = await getDecision({
      req,
      resource: "deck_create",
      scope: "deck_create:create",
    });
    if (!decision) {
      res.status(401).json({ error: "access_denied" });
    } else {
      const { name } = req.params;
      const { username } = grantAuthN;

      const [err, data] = trainerStore.createDeck({
        username,
        name,
      });
      if (err) {
        res.status(400).json({ error: err.kind });
      } else {
        await resources.createDeckListResource(username);
        await resources.createDeckResource(username, name);
        res.status(201).json(data);
      }
    }
  }
});

app.get("/deck-list", async (req, res) => {
  const grantAuthN = await checkAuth(req);
  if (!grantAuthN) {
    res.status(401).json({ error: "access_denied" });
  } else {
    const { username } = grantAuthN;

    const decision = await getDecision({
      req,
      resource: resources.encodeResourceName("deck_list", username),
      scope: "deck_list:read",
    });

    if (!decision) {
      res.status(401).json({ error: "access_denied" });
    } else {
      const deckList = trainerStore.getDeckList({ username });
      res.status(200).json(deckList);
    }
  }
});

app.get("/deck/:username/:name", async (req, res) => {
  const grantAuthN = await checkAuth(req);
  if (!grantAuthN) {
    res.status(401).json({ error: "access_denied" });
  } else {
    const { username, name } = req.params;
    const decision = await getDecision({
      req,
      resource: resources.encodeResourceName("deck", username, name),
      scope: "deck:read",
    });
    if (!decision) {
      res.status(403).json({ error: "access_denied" });
    } else {
      const [err, data] = trainerStore.getDeck({
        username,
        name,
      });
      if (err) {
        res.status(400).json({ error: err.kind });
      } else {
        res.status(200).json(data);
      }
    }
  }
});

app.patch("/deck/:username/:name", async (req, res) => {
  const grantAuthN = await checkAuth(req);
  if (!grantAuthN) {
    res.status(401).json({ error: "access_denied" });
  } else {
    const { username, name } = req.params;
    const decision = await getDecision({
      req,
      resource: resources.encodeResourceName("deck", username, name),
      scope: "deck:write",
    });
    if (!decision) {
      res.status(403).json({ error: "access_denied" });
    } else {
      const pokemons = req.body;
      if (
        !Array.isArray(pokemons) ||
        pokemons.length > 6 ||
        pokemons.some((el) => typeof el !== "string")
      ) {
        res.status(400).json({
          error:
            "Body should be a JSON array of pokemon names with length <= 6.",
        });
      } else {
        const [err, data] = trainerStore.updateDeck({
          username,
          name,
          pokemons,
        });
        if (err) {
          res.status(400).json({ error: err.kind });
        } else {
          res.status(200).json(data);
        }
      }
    }
  }
});

app.delete("/deck/:username/:name", async (req, res) => {
  const grantAuthN = await checkAuth(req);
  if (!grantAuthN) {
    res.status(401).json({ error: "access_denied" });
  } else {
    const { username, name } = req.params;
    const decision = await getDecision({
      req,
      resource: resources.encodeResourceName("deck", username, name),
      scope: "deck:delete",
    });
    if (!decision) {
      res.status(403).json({ error: "access_denied" });
    } else {
      const [err] = trainerStore.deleteDeck({
        username,
        name,
      });
      if (err) {
        res.status(400).json({ error: err.kind });
      } else {
        res.status(204).end();
      }
    }
  }
});

app.listen(3069, "127.0.0.1", () => {
  console.log("api-trainer listening at http://%s:%s", "127.0.0.1", 3069);
});

async function getDecision(params: {
  req: express.Request;
  resource: string;
  scope: string;
}): Promise<boolean> {
  const { req, resource, scope } = params;
  const permission = `${resource}#${scope}`;
  return new Promise((resolve) => {
    keycloak
      .checkPermissions(
        {
          response_mode: "permissions",
          permissions: [{ id: resource, scopes: [scope] }],
        },
        req,
        (permissions: Array<{ scopes: string[]; rsname: string }>) => {
          const set = new Set<string>();
          permissions.forEach(({ rsname, scopes }) => {
            scopes.forEach((scope) => {
              set.add(`${rsname}#${scope}`);
            });
          });
          resolve(set.size === 1 && set.has(permission));
        }
      )
      .catch((err) => {
        console.error("Could not get decision");
        console.error(err);
        resolve(false);
      });
  });
}

async function checkAuth(
  req: express.Request
): Promise<null | { username: string }> {
  const grant = await keycloak.getGrant(req, undefined!).catch((err) => {
    console.error(err);
    return null;
  });
  if (!grant) {
    return null;
  }
  return {
    username: (grant.access_token as any).content.preferred_username,
  };
}
